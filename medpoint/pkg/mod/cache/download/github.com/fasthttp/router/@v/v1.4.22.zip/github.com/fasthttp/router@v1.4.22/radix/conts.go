package radix

const (
	root nodeType = iota
	static
	param
	wildcard
)
